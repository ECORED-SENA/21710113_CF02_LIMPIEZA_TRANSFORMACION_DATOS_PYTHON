function ExecuteScript(strId)
{
  switch (strId)
  {
      case "5uX1QArp0rO":
        Script1();
        break;
  }
}

function Script1()
{
  window.close();
}

